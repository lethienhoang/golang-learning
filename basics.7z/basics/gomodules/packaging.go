package main

import (
	"gomodules/mymath"
)

func main() {
	var sum = int
	sum = mymath.Add(10, 1)
}
